package com.rnd.bike.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.rnd.bike.model.Bike;
import com.rnd.bike.repositories.BikeRepository;

//@EnableJpaRepositories("com.rnd.bike.repositories")
@RestController
@RequestMapping("/api/bikes")
public class BikesController {
  
	@Autowired
    private BikeRepository bikeRepository;
    
    @GetMapping
    public List<Bike> list(){
        System.out.println("------list-------");
        /*
         * List<Bike> bikes = new ArrayList<>();
         * 
         * Bike bike1 = new Bike(); bike1.setName("b1"); bike1.setEmail("aa@gmail.com");
         * bikes.add(bike1); return bikes;
         */
        return bikeRepository.findAll();
    }
    
    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public void create(@RequestBody Bike bike) {
        System.out.println("------create-------");
        bikeRepository.save(bike);
    }

    @GetMapping("/{id}")
    public Bike get(@PathVariable("id") long id) {
        System.out.println("------GET-------");
        return bikeRepository.getOne(id);
    }
}


